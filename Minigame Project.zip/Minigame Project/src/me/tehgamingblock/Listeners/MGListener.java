package me.tehgamingblock.Listeners;

import org.bukkit.event.Listener;

import me.tehgamingblock.MinigameProject;

public class MGListener implements Listener{
	
	MinigameProject plugin;
	
	public MGListener(MinigameProject pl){
		plugin = pl;
	}

}
